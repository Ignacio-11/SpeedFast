import model.*;

public class Main {

    public static void main(String[] args) {

        Pedido p1 = new PedidoComida(001, "Plaza de Armas", 0.3);
        Pedido p2 = new PedidoEncomienda(002, "Lebu", 642);
        Pedido p3 = new PedidoExpress(003, "Viña del Mar", 87);

        Pedido[] pedidos = {p1, p2, p3};

        System.out.println("=== SISTEMA DE ENTREGA  ===\n");

        for (Pedido p : pedidos) {
            p.mostrarResumen();
            System.out.println("Tiempo estimado: "
                    + p.calcularTiempoEntrega() + " minutos");
            System.out.println("=============================");
        }
    }
}
