Buenas, el proyecto tiene la funcionalidad pedida, pero se le deben realizar pruebas para comprobarlo, dejaré explicado como se puede hacer pruebas unitarias para verificar el correcto funcionamiento del programa.

        repartidores.add(new Repartidor("Ignacio Yañez", true, true, 0.1));
        repartidores.add(new Repartidor("Moca", true, true, 4.5));

En ese fragmento, se pueden realizar varios cambios, ubicados en el Main, podemos cambiar el "true" por el "false" para ver que el mensaje de adapta dependiendo si lo que decimos está bien o no.

Y bueno, eso sería todo, gracias por leer :)

PD: Moca es el nombre de mi nueva perrita, tiene 5 meses apenas y quise incluirla en mi proyecto :)