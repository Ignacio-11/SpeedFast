package model;

import java.util.ArrayList;

public class PedidoEncomienda extends Pedido {

    public PedidoEncomienda(int id, String direccion) {
        super(id, direccion, "Encomienda");
    }

    @Override
    public void asignarRepartidor(ArrayList<Repartidor> repartidores) {

        System.out.println("=== Pedido tipo Encomienda ===");
        System.out.println("Asignando a un repartidor, por favor espere.");

        for (Repartidor r : repartidores) {
            if (r.isDisponible()) {
                r.setDisponible(false);
                System.out.println("El peso y embalaje es válido.");
                System.out.println("Repartidor asignado: " + r.getNombre());
                return;
            }
        }
        System.out.println("No hay repartidores disponibles.");
    }
}
