package model;

import java.util.ArrayList;

public class PedidoComida extends Pedido {

    public PedidoComida(int id, String direccion) {
        super(id, direccion, "Comida");
    }

    @Override
    public void asignarRepartidor(ArrayList<Repartidor> repartidores) {

        System.out.println("=== Pedido tipo Comida ===");
        System.out.println("Asignando a un repartidor, por favor espere.");

        for (Repartidor r : repartidores) {
            if (r.isDisponible() && r.tieneMochila()) {
                r.setDisponible(false);
                System.out.println("¡Mochila termica disponible!");
                System.out.println("Repartidor asignado: " + r.getNombre());
                return;
            }
        }
        System.out.println("No hay repartidores disponibles.");
    }
}
