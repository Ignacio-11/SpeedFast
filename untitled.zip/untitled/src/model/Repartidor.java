package model;

public class Repartidor {

    private String nombre;
    private boolean mochilaTermica;
    private boolean disponible;
    private double distanciaKm;

    public Repartidor(String nombre, boolean mochilaTermica, boolean disponible, double distanciaKm) {
        this.nombre = nombre;
        this.mochilaTermica = mochilaTermica;
        this.disponible = disponible;
        this.distanciaKm = distanciaKm;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tieneMochila() {
        return mochilaTermica;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public double getDistanciaKm() {
        return distanciaKm;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
