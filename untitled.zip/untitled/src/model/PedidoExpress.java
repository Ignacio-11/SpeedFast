package model;

import java.util.ArrayList;

public class PedidoExpress extends Pedido {

    public PedidoExpress(int id, String direccion) {
        super(id, direccion, "EXPRESS");
    }

    @Override
    public void asignarRepartidor(ArrayList<Repartidor> repartidores) {

        System.out.println("=== Pedido tipo Express ===");
        System.out.println("Asignando repartidor...");

        Repartidor mejor = null;

        for (Repartidor r : repartidores) {
            if (r.isDisponible()) {
                if (mejor == null || r.getDistanciaKm() < mejor.getDistanciaKm()) {
                    mejor = r;
                }
            }
        }

        if (mejor != null) {
            mejor.setDisponible(false);
            System.out.println("Repartidor encontrado, por favor espere..");
            System.out.println("Repartidor asignado" + mejor.getNombre());
        } else {
            System.out.println("No hay repartidores disponibles.");
        }
    }
}
