package model;

import java.util.ArrayList;

public class Pedido {

    protected int idPedido;
    protected String direccionEntrega;
    protected String tipoPedido;

    public Pedido(int idPedido, String direccionEntrega, String tipoPedido) {
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega;
        this.tipoPedido = tipoPedido;
    }

    public void asignarRepartidor(ArrayList<Repartidor> repartidores) {
        System.out.println("Asignando a un repartidor");
    }

    public int getIdPedido() {
        return idPedido;
    }
}
