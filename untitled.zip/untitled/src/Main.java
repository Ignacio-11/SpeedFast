import model.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<Repartidor> repartidores = new ArrayList<>();
        repartidores.add(new Repartidor("Ignacio Yañez", true, true, 0.1));
        repartidores.add(new Repartidor("Moca", true, true, 4.5));

        Pedido p1 = new PedidoComida(101, "Las Condes");
        Pedido p2 = new PedidoEncomienda(102, "Las Parcelas");


        p1.asignarRepartidor(repartidores);
        p2.asignarRepartidor(repartidores);
    }
}
